import json
import os
import requests

def lambda_handler(input, context):
    # Get a dictionary object from JSON formatted input
    parsed_input = json.loads(input)
    
    # Exit of "text" key is not found in input
    if 'text' not in parsed_input:
        return json.dumps({"KeyError":"Key \'text\' not found!"})
    
    url = os.getenv("SLACK_URL")
    response = requests.post(url=url, data=parsed_input["text"])

    return response.text